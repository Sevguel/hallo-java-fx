package de.skymatic.javafxtest;

import javafx.scene.control.TextField;

public class TypeText {

    private final String fname;
    private final String lname;
    
  public  TypeText(){

  this.fname = "";
  this.lname = "";
  
  }
    public String getFname() {
  return fname;
}
public String getLname() {
  return lname;
}
  public TypeText(String fname,
                     String lname) {
        this.fname = fname;
        this.lname = lname;
    }
}
