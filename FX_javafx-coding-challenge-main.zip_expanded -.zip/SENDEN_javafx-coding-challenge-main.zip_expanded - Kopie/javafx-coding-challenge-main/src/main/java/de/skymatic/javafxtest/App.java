package de.skymatic.javafxtest;

import de.skymatic.javafxtest.SystemInfo;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Dialog;

import java.util.Optional;

/**
 * JavaFX App
 */
public class App extends Application {

    private final TextField forFilField= new TextField();

  @Override
  public void start(Stage stage) {
    var javaVersion = SystemInfo.javaVersion();
    var javafxVersion = SystemInfo.javafxVersion();

    var label = new Label("Hello, JavaFX " + javafxVersion + ", running on Java " + javaVersion + ".");
    var textInputFiled = new TextField();
    textInputFiled.setPromptText("Test text field: Enter anything you want.");
    var button = new Button("Test Button");
   
    button.setOnAction((EventHandler<ActionEvent>) new EventHandler<ActionEvent>() {
    	
    	public void handle(ActionEvent e) {
    		
    		 Dialog<TypeText> dialog= new ShowDialog(new TypeText(textInputFiled.getText()+ "",""));
    	        Optional<TypeText> result = dialog.showAndWait();  
    	        if(result.isPresent()) {
    	        	TypeText showText=result.get();
    	        	
    	        	textInputFiled.setText(showText.getFname()+"   \n"+showText.getLname()+"  ");

    	        }
    	        
    	System.out.println("** HERE  HERE  ** ");
    	}
    	});
    
    var vbox = new VBox(label, textInputFiled, button);
    vbox.setPadding(new Insets(20));
    vbox.setAlignment(Pos.CENTER);
    vbox.setSpacing(10);

    var text = new Text("子貢問曰：有一言而可以終身行之者乎？子曰：其恕乎！己所不欲、勿施於人。"); //https://en.wikipedia.org/wiki/Confucius
    var quoteBox = new HBox(text);
    quoteBox.setAlignment(Pos.BOTTOM_RIGHT);
    HBox.setMargin(text, new Insets(20));

    var stackPane = new StackPane(quoteBox, vbox);
    var scene = new Scene(stackPane, 640, 480);
    stage.setScene(scene);
    stage.setTitle("JavaFX Test App");
    stage.show();
  }

  public static void main(String[] args) {
    launch();
  }

}
