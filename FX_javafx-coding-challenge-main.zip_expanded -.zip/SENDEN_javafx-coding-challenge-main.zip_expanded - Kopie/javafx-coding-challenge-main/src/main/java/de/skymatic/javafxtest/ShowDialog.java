package de.skymatic.javafxtest;

import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;

public class ShowDialog extends Dialog<TypeText> {

    private final TextField fname = new TextField();
    private final TextField lname = new TextField();

    public ShowDialog() {}

    public ShowDialog(TypeText showText) {
        setTitle("MODAL_DIALOG_JAVA_FX_HERE");
        Label fnameLabel = new Label("fname");
        Label lnameLabel = new Label("lname");
      
        VBox vbox = new VBox(
                fnameLabel, fname,
                lnameLabel,lname);

        DialogPane dpane = getDialogPane();

        ButtonType btOK = new ButtonType("OK", ButtonBar.ButtonData.OK_DONE);
        dpane.getButtonTypes().addAll( btOK, ButtonType.CANCEL );
        dpane.setContent( vbox );
        
        vbox.setSpacing( 80 );
        vbox.setPadding( new Insets(90) );
        setResultConverter( this::bnTyp );

        showText( showText );
    }

    private void showText(TypeText aboutText) {
        if (aboutText != null) {
            fname.setText( aboutText.getFname() );
            lname.setText( aboutText.getLname());
        }
    }
    private TypeText bnTyp(ButtonType btTyp) {
        TypeText  showText = null;
        if( btTyp.getButtonData() == ButtonBar.ButtonData.OK_DONE ) {
        	showText = new TypeText(
                    fname.getText(), lname.getText()
            );
        }
        return showText;
    }
}