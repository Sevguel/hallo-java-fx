module de.skymatic.javafxtest {
    requires javafx.controls;
	requires java.desktop;
	requires javafx.base;
    exports de.skymatic.javafxtest;
}